package filehandling;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
public class filehandlingproj {
	 public static void CreateFileUsingFileClass() throws IOException
     {
   	  File file = new File("D:\\prashanth123.txt");
   	  if (file.createNewFile())
   	      System.out.println("file is created");
   	  else 
   		  System.out.println("file is already exist");
   	  FileWriter writer = new FileWriter(file);
   	  writer.write("welcome to simplilearn");
   	  writer.close();
   	  }
	 public static  void FileInputStream() throws IOException
	     {
	    	 FileInputStream stream = new FileInputStream("D:\\prashanth123.txt");
	    	 int data;
	    	 while((data=stream.read())!=-1)
	    	 {
	    		 System.out.print((char)(data));
	    	 }
	     }
      public static void createFileUsingNIO() throws IOException
		{
			Path path = Paths.get("D:\\prashanth123.txt");
			System.out.println("\n");
			String input=" \nIm s.prashanth   ";
			byte array[]=input.getBytes();
			Files.write(path, array, StandardOpenOption.CREATE,StandardOpenOption.APPEND);
			System.out.println("Data Written Successfully");
			}
	  public static void main(String args[])
	 {
		 try {
			CreateFileUsingFileClass();
			FileInputStream();
			createFileUsingNIO();
		  } catch (IOException e) {
			  e.printStackTrace();
		}
	 }
}
