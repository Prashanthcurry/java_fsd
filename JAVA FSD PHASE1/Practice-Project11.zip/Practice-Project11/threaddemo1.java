package com.multithreading.synchronization;

public class threaddemo1 extends Thread {
	
	public void run()
	{
		System.out.println("thread started");
	}
    public static void main(String args[])
    {
        threaddemo1 ex1 = new threaddemo1();
        threaddemo1 ex2 = new threaddemo1();
        ex1.start();
        ex2.start();
      }
}
