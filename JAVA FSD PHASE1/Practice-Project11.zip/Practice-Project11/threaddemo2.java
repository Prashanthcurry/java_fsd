package com.multithreading.synchronization;

public class threaddemo2 implements Runnable {
	public void run()
	{
		for(int i=1;i<5;i++)
		{
			System.out.println(i+" "+Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
     public static void main(String args[])
     {
    	 threaddemo2 ex3 = new threaddemo2();
    	 threaddemo2 ex4 = new threaddemo2();
    	 Thread t1 = new Thread(ex3);
    	 Thread t2 = new Thread(ex4);
    	 t1.setName("prashanth");
    	 t2.setName("sarvesh");
    	 t1.start();
    	 t2.start();
     }
}
