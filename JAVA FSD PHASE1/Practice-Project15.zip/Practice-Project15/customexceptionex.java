package com.exception;

public class customexceptionex extends Exception {
	
	public customexceptionex(String s) {
		// TODO Auto-generated constructor stub
		super(s);
		
	}

      public static void main(String args[])
      {
    	  try
    	  {
    		  throw new customexceptionex("temp");
    	  }
    	  
    	  catch(customexceptionex ex)
    	  {
    		  System.out.println("caught");
    		  System.out.println(ex.getMessage());
    	  }
      }
}

