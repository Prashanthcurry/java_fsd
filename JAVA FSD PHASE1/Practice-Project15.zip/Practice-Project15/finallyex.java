package com.exception;

public class finallyex {
        public static void main(String[] args) {
			int arr[]= {1,2,3,4,5};
			try
			{
				arr[6]=30;
			}
			catch(Exception e)
			{
				System.out.println("ERROR: " +e);
			}
			
			finally
			{
			System.out.println("finally  block is executed");
			}
			
		}
}
