package com.exception;

public class throwsex {
	
	void division() throws ArithmeticException
	{
		int a =45,b=0,rs;
		rs=a/b;
		System.out.println("the result is: " +rs);
	}
	public static void main(String args[])
	{
		throwsex t = new throwsex();
		try {
			t.division();
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		
		System.out.println("end of program");
	}
}
