package customexceptionex;

public class agenotvalidex extends Exception{
	public String msg;

	public agenotvalidex(String msg) {
		super();
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "agenotvalidex [msg=" + msg + "]";
	}
	
	
       
}
