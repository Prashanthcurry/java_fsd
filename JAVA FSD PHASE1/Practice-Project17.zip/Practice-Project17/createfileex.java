package com.file;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class createfileex {
      public static void CreateFileUsingFileClass() throws IOException
      {
    	  File file = new File("D:\\testFile22-07-22.txt");
    	  if (file.createNewFile())
    	  {
    		  System.out.println("file is created");
    	  }
    	  
    	  else {
    		  System.out.println("file is already exist");
    	  }
    	  
    	  FileWriter writer = new FileWriter(file);
    	  writer.write("welcome to simplilearn");
    	  writer.close();
    	  //FileWriter writer = new FileWriter(file);
    	  //writer.write("welcome");
    	  //writer.close();
    	  
      }
      
      
      public static void CreateFileUsingOutputStream() throws IOException
      {
    	  
    	  FileOutputStream out = new FileOutputStream("D:\\testFileOutPutStream.txt");
    	  String input="welcome prashanth";
    	  byte array[]=input.getBytes();
    	  out.write(array);
    	  System.out.println("Data Written Successfully");
  		  out.close();
      }
      public static void main(String args[])
      {
    	  try {
			CreateFileUsingFileClass();
			//CreateFileUsingOutputStream();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      }
}
