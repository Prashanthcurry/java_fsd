package com.file;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class deletefileex  {
	public static void deletefile() throws IOException
	{
		Path path = Paths.get("D:\\testFile22-07-22.txt");
		if(Files.deleteIfExists(path))
			System.out.println("file deleted");
		else
			System.out.println("file not deleted");
	}
	
	public static void main(String args[])
	{
		try {
			deletefile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
     
}
