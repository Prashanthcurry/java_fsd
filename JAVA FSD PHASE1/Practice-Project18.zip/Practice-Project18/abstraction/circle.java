package com.abstraction;

public class circle extends shape{
	double radius;

	public circle(double radius,String color) {
		super(color);
		this.radius = radius;
	}
	
   double area()
   {
	   return Math.PI * Math.pow(radius, 2);
   }


   
   @Override


public String toString() {
	return "circle color:"  +getColor()+  "  and  area  is:"+area();
}

   

   
	
	
}
