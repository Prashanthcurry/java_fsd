package com.abstraction;

public class rectangle extends shape {
	public double length;
	public double breadth;

	public rectangle(String color, double length, double breadth) {
		super(color);
		this.length = length;
		this.breadth = breadth;
	}

   
	double area()
	{
		return length*breadth;
	}

	
     
	
	  @Override
		public String toString() {
			return "rectangle color ="  +getColor()+  " and area is :"+area();
		}

	
	
}
