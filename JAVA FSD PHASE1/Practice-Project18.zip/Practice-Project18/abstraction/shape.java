package com.abstraction;

abstract class shape {
	 public String color;
	 
	 abstract double area();
	
	 public shape(String color) {
		
		this.color = color;
	}
	 
     public String getColor()
     {
    	 return color;
     }
}

