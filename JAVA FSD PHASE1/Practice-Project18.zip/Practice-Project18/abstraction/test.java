package com.abstraction;

public class test {
     public static void main(String args[])
     {
    	 shape s = new circle(2,"blue");
    	 shape s1 = new rectangle("red",2.2,2);
    	 System.out.println(s);
    	 System.out.println(s1);
    	 
    	 
     }
}
