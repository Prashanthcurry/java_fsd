package com.gettersetter;

public class getsetterexample {
     public static void main(String args[])
     {
    	 student s1=new student();
    	 s1.setName("prashanth");
    	 s1.setRollno(1);
    	 s1.setAddress("chennai");
    	 System.out.println(s1);
    	 System.out.println("The name is "+ s1.getName());
    	 System.out.println("The rollno is "+s1.getRollno());
    	 System.out.println("The address is" +s1.getAddress());
    	
     }
}
