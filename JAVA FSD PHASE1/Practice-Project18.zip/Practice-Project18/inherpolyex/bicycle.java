package inherpolyex;

public class bicycle {
         int gear;
         int speed;
		
         public bicycle(int gear, int speed) {
			super();
			this.gear = gear;
			this.speed = speed;
		}

		
         
         
         
}
