package inherpolyex;

public class classobjexam {
	String name;
	int rollno;
	String country;
	
	public classobjexam(String name, int rollno, String country) {
		super();
		this.name = name;
		this.rollno = rollno;
		this.country = country;
	}
	
	void display()
	{
		System.out.println("The name is " +name);
		System.out.println("The Rollno: " +rollno);
		System.out.println("The country: " +country);
	}
	

	public static void main(String args[])
      {
       classobjexam ex = new classobjexam("prashanth",1,"india");
       ex.display();
       
}
}
