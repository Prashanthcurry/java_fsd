package inherpolyex;

public class inheritanceex {
         public static void main(String args[])
         {
        	 mountainbike b = new mountainbike(5,100,5);
        	 System.out.println(b);
         }
}
