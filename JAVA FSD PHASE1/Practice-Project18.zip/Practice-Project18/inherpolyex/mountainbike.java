package inherpolyex;

public class mountainbike extends bicycle {
	int height;

	public mountainbike(int gear, int speed, int height) {
		super(gear, speed);
		this.height = height;
	}

	
	
	public String toString() {
		return (" no of gears are : " + gear + "\n" + " speed of bicycle :" + speed + "\n" + "height is :" +height);
	}
     

}
