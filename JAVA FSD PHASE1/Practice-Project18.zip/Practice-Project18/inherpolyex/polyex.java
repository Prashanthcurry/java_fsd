package inherpolyex;

public class polyex {
	
     int add(int a ,int b)
	{
		return a+b;
	}
	
	double  add(double a , double b)
	{
		return a+b;
	}
	
	int add(int a , int b,int c)
	{
		return a+b+c;
	}
	
	public static void main(String args[])
        {
        	polyex ex = new polyex();
        	System.out.println(ex.add(2, 2));
        	System.out.println(ex.add(2.2,2.3));
        	System.out.println(ex.add(2, 2,2));
        }
}
