package inherpolyex;

interface first
{
	default void show()
	{
		System.out.println("default first");
	}
}

interface second
{
	default void show()
	{
		System.out.println("default second");
	}
}
public class multipleinheri implements first,second {
	@Override
	public void show() {
		// TODO Auto-generated method stub
		first.super.show();
		second.super.show();
	}
	
	public static void main(String args[])
	{
		multipleinheri ob = new multipleinheri();
		ob.show();
	}

}
