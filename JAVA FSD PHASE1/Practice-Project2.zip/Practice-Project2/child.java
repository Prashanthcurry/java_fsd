package com.ex.phase1;
import com.phase1.*;
	public class child extends accessmodifier {
		public static void main(String [] args) {
			child obj= new child();
		
			//default and private method outside the class and outside 
			//the package(another package) is not permissible
			//obj.methodDefault();
			//obj.methodPrivate();
			obj.methodProtected();
			obj.methodPublic();
			}
}
