package com.ex.phase1;
import com.phase1.*;

public class testaccessinanotherpackage {
public static void main(String [] args) {
		
		accessmodifier obj= new  accessmodifier();
		
		
		///public method is a globally accessible to all classes and packages
		//obj.methodDefault();
		//obj.methodPrivate();
		//obj.methodProtected();
		obj.methodPublic();
}
}
