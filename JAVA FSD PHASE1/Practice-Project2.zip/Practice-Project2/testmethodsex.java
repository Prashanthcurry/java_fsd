package com.phase1;

public class testmethodsex {
	public static void main(String [] args) {
		
	     accessmodifierex obj= new  accessmodifierex();
			
			obj.methodDefault();
			//obj.methodPrivate(); private method we can't access out side of class, its scope is within the class
			obj.methodProtected();
			obj.methodPublic();
		}
}
