package arrayrotationex;

public class main {
         public static void main(String[] args) {
			  arrayrotationdemo ex = new arrayrotationdemo();
			  int arr[]= {1,2,3,4,5,6,7};
			  ex.rotate(arr,10);///passing array and number of  times to  rotate an array
			  
			  for(int i=0;i<arr.length;i++)
			  {
				  System.out.print(arr[i]+" ");
			  }
		}
}
