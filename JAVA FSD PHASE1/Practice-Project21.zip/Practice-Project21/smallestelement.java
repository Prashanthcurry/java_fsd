package datastructuresex;

import java.util.Arrays;

public class smallestelement {
	public static int display(int num[],int k)
	{
		Arrays.sort(num);
		return num[k-1];
	}
	
    public static void main(String[] args) {
	        int arr[]= {6,5,4,3,2,1};
			
			int k=4;
			System.out.println("4th smallest element:"+ display(arr,4) );
			
			
		}
}
