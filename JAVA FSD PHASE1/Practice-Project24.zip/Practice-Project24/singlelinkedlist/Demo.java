package singlelinkedlist;

public class Demo {
    public static void main(String[] args) {
		LinkedList list = new LinkedList();
		
		list.InsertAtBeginning(10);
		list.InsertAtBeginning(9);
		list.InsertAtBeginning(8);
		list.InsertAtBeginning(6);
		list.display();
		
		//System.out.println();
		//list.insertAtPos(1,99);
		//list.display();
		
		System.out.println();
		//list.insertAtPos(10,7);
		//list.display();
		
		list.DeleteAtPos(0);
		list.display();
		
	}
}
