package singlelinkedlist;

public class LinkedList {
	     Node head;
         class Node
         {
        	 int data;
        	 Node next;
         }
         
         LinkedList()
         {
        	 head=null;
         }

		public void InsertAtBeginning(int value) {
			// TODO Auto-generated method stub
			 Node newnode = new Node();
			 newnode.data=value;
			 newnode.next=null;
			 if(head==null)
			      head=newnode;
			 else
				 newnode.next= head;
			     head=newnode;
				 
			 }
		public void display()
		{
			Node temp =head;
			while(temp!=null)
			{
				System.out.print(temp.data + " ");
				temp=temp.next;
			}
		}

		public void insertAtPos(int pos, int val) {
			// TODO Auto-generated method stub
			if(pos==0)
			{
				InsertAtBeginning(val);
				return;
			}
			Node newnode = new Node();
			newnode.data=val;
			newnode.next=null;
			Node temp=head;
			for(int i=0;i<pos-1;i++)
			{
				temp=temp.next;
				if(temp==null)
				{
					throw new IndexOutOfBoundsException("invalid enter the correct position");
				}
				
			}
			newnode.next = temp.next;
			temp.next= newnode;
			
		}

		public void DeleteAtPos(int pos) {
			if(head==null)
			{
				throw new IndexOutOfBoundsException("list is empty");
			}
			
			if(pos==0)
			{
				head=head.next;
				return;
			}
			// TODO Auto-generated method stub
			Node temp = head;
			Node prev = null;
			
			for(int i=1;i<=pos;i++)
			{
				prev = temp;
				temp=temp.next;
				
			}
			prev.next = temp.next;
			
		}
		
		
}
