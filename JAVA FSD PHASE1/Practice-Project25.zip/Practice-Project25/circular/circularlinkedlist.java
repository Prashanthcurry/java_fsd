package circular;

import java.lang.reflect.Array;

public class circularlinkedlist {
      Node last;
      class Node
      {
    	  int data;
    	  Node next;
      }
      
      circularlinkedlist(){
  		last = null;
  	}
      
      public void insertAtBeginning(int val){
  		Node newNode = new Node();
  		newNode.data=val;
  		newNode.next=null;
  		if(last==null) {
  			newNode.next = newNode;
  			last = newNode;
  		}
  		else {
  			newNode.next = last.next;
  			last.next = newNode;
  		}
  	
  	}
  	
  	public void insertAtEnd(int val){
  		Node newNode = new Node();
  		newNode.data=val;
  		newNode.next=null;
  		if(last==null) {
  			newNode.next = newNode;
  			last = newNode;
  		}
  		else {
  			newNode.next = last.next;
  			last.next = newNode;
  			last=newNode;
  		}
  	
  	}
  	
  	public void display() {
  		if(last==null)
  			return;
  		Node temp = last.next;
  		do{
  			System.out.print(temp.data + " ");
  			temp = temp.next;
  		}while(temp!=last.next);
  		
  		
  	}
  	
  
}
