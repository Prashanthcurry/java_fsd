package circular;



public class demo
{
	public static void main(String[] args) {
		circularlinkedlist list = new circularlinkedlist();
		list.insertAtBeginning(5);
		list.insertAtBeginning(4);
		list.insertAtBeginning(3);
		list.insertAtBeginning(2);
		list.insertAtBeginning(1);
		list.display();
		
}
}