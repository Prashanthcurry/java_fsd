package doublelinkedlist;



public class Doublelinkedlist {
	Node head;
	Node tail;
        class Node
        {
       	 int data;
       	 Node prev;
       	 Node next;
        }
        
        Doublelinkedlist()
        {
       	 head=null;
       	 tail=null;
        }

      
        public void InsertAtBeginning(int value) {
			// TODO Auto-generated method stub
			 Node newnode = new Node();
			 newnode.data=value;
			 newnode.next=null;
			 newnode.prev=null;
			 newnode.next=head;
			 if(head==null)
			 {
			      tail=newnode;
			 }
			 else
			 {
				 head.prev = newnode;
			 }
				 
			 
             head = newnode;
          }           
		public void display()
		{
			Node temp =head;
			while(temp!=null)
			{
				System.out.print(temp.data + " ");
				temp=temp.next;
			}
		}

		public void displayRev() {
			if(head==null)
				System.out.println("List is empty");
			Node temp = tail; //start from head
			while(temp != null) { //null implies end of list
				System.out.print(temp.data + " ");
				temp = temp.prev; //jump
			}
}

}
