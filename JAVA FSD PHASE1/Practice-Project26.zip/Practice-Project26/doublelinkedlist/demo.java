package doublelinkedlist;


public class demo {
	public static void main(String[] args) {
		Doublelinkedlist list = new Doublelinkedlist();
		list.InsertAtBeginning(1);
		list.InsertAtBeginning(3);
		list.InsertAtBeginning(10);
		
		list.display();
		System.out.println();
		System.out.println("after reversing");
		list.displayRev();
	}
      
}
