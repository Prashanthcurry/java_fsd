package datastructuresex;

public class stack {
	static int s[]= new int[10];
	int tos;
	stack()
	{
		tos=-1;
	}
	void push(int item)
	{
		if(tos==9)
			System.out.println("stack is full");
		else
			s[++tos]=item; //tos is incremented and then pushed in 0th index from -1
		    System.out.println(item + " is pushed into stack");
	}
	
	int pop()
	{
		if(tos>=0)
		{
			 return s[tos--];// tos is popped and then decremented from the value 
			 
		}
		else
		{
			System.out.println("stack is empty");
			return -1;
		}
	}
       
	public static void main(String[] args) {
		stack se = new stack();
		se.push(10);
		se.push(20);
		se.push(30);
		System.out.println(se.pop() + " is popped from stack");
		
	}
}
