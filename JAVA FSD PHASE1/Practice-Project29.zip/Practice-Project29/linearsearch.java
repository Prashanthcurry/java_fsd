package datastructuresex;

import java.util.Scanner;

public class linearsearch {
       public static void main(String args[])
       {
    	   Scanner sc = new Scanner(System.in);
    	   int arr[]= {1,2,3,4,5};
    	   System.out.println("enter the number to be searched");
    	   int search = sc.nextInt();
    	   int i;
    	   for( i=0;i<arr.length;i++)
    	   {
    		   if(arr[i]==search)
    		   {
    			   System.out.println("The number at the index " +i);
    			   break;
    		   }
    	   }
    	   if(arr.length==i)
    	   {
    		   System.out.println("no element");
    	   }
    	   
    	  
    	  }
    	  
    	   
       }

