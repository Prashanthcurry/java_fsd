package com.method;

public class callbyvalueex {
	int num=100;
	
	void operation (int num)
	{
		this.num=num*10/100;
	}
	
   public static void main(String args[])
   {
	   callbyvalueex s = new callbyvalueex();
	   System.out.println("value of num before call function "+s.num);
	   
	   s.operation(100);
	   System.out.println("value of num after call function "+s.num  );
	   
	   
	   
	   
	   
	   
	   
	   
   }
}
