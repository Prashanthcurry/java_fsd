package com.method;

public class methodex {
	public void display()
	{
		System.out.println("Displayed");
	}
	public String fullname(String fname,String lname)
	{
		return fname+ " "+lname;
		
	}
	
	public void location(String place)
	{
		System.out.println("The location is "+place);
	}
	
	public int operation(int num)
	{
		return num+num ;
	}
    
	public static void main(String args[])
    {
    	methodex s = new methodex();
    	s.display();
    	System.out.println("The name is "+s.fullname("prashanth","curry"));
    	s.location("kanchipuram");
    	
    	s.operation(10);
    	System.out.println("The addition is "+s.operation(10));
    	
    }
}
