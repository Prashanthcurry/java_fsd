package com.method;

public class methodoverloadingex {
  
	public int add(int a ,int b)
	{
		return a+b;
		
	}
	
	public int add(int a , int b ,int c)
	{
		return a+b+c;
	}
	
	public double add(double  a ,double b)
	{
		return a+b;
	}
	public float add(float a,float b)
	{
		return a+b;
	}
	
	public static void main(String args[])
	{
		methodoverloadingex s = new methodoverloadingex();
		System.out.println("Addition of 10 and 2 is " +s.add(10, 2));
		System.out.println("Addition of 10.3 and 2.2 is " +s.add(10.3f, 2.2f));
		System.out.println("Addition of 5.6 and 7.7 is "+s.add(5.6,7.7));
		System.out.println("Addition of 8,9,2 is "+s.add(8, 9,2));
	}
}
