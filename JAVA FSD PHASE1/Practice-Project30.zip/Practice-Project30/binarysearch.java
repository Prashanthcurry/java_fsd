package datastructuresex;

import java.util.Arrays;
import java.util.Scanner;
public class binarysearch {
        public static void main(String args[])
        {
            int arr[]= {10,20,30,40,50};
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the element to be searched");
            int key=sc.nextInt();
            int result = Arrays.binarySearch(arr,key);
            if(result<0)
            {
            	System.out.println("no element");
            }
            else
            {
            	System.out.println("the element at the poistion "+result);
            }
            
        	
        }
}

