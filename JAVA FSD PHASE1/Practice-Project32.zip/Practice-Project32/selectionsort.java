package datastructuresex;

public class selectionsort {
      public static void main(String args[])
      {
    	  int arr[]= {10,5,26,3,15,22};
    	  for(int i=0;i<arr.length;i++)
    	  {
    		  int minindex=i;
    		  for(int j=i+1;j<arr.length;j++)
    		  {
    			  if(arr[j]<arr[minindex])
    			  {
    				  minindex=j;
    			  }
    		  }
    		  
    		  int temp = arr[i];
    		  arr[i]=arr[minindex];
    		  arr[minindex]=temp;
    	  }
    	  
    	  for (int i:arr)
    		  System.out.print(i +" ");
    	 
    	 
      }
}
