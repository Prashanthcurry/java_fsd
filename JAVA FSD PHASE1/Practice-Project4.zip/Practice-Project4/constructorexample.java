package com.constructor;

public class constructorexample {
      String name;
      int rollno;
      String location;
      
      constructorexample()
      {
    	  name="sarvesh";
    	  rollno=1;
    	  location="chennai";
    	  
       }

	public constructorexample(String name, int rollno, String location) {
		super();
		this.name = name;
		this.rollno = rollno;
		this.location = location;
	}
	
	void display()
	{
		System.out.println(" The name is "+name);
		System.out.println("The rollno is "+rollno);
		System.out.println("The location is "+location);
		
	}
	
	public static void main(String args[])
	{
		System.out.println("Default constructor");
		constructorexample ex = new constructorexample();
		ex.display();
		System.out.println("\n");
		System.out.println("Paramaterized constructor");
		constructorexample ex1 = new constructorexample("prashanth",2,"kanchipuram");
		ex1.display();
		
		
	}
      
}
