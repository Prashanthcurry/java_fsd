package com.collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Vector;


public class collectionsex {
	public static void main(String args[])
	{
		
		//arraylist
		System.out.println("Arraylist");
		ArrayList<Integer> list = new ArrayList<Integer>();
	     list.add(10);
	     list.add(100);
	     list.add(20);
	     System.out.println(list);
	     
	     
	     //vector
	     System.out.println("\n");
	     System.out.println("vector");
	     Vector<String> vec = new Vector<String>();
	     vec.addElement("prashanth");
	     vec.addElement("sarvesh");
	     System.out.println(vec);
	     System.out.println("\n");
	     System.out.println("Linkedlist");
	     
	     //linkedlist
	     LinkedList<Integer> lin = new LinkedList<>();
	     lin.add(10);
	     lin.add(20);
	     lin.add(1);
	     Iterator<Integer> itr = lin.iterator();
	     while(itr.hasNext())
	     {
	    	 System.out.println(itr.next());
	     }
	     System.out.println("\n");
	     System.out.println("hashset");
	     
	     //hashset
	     
	     HashSet<Integer> set = new HashSet<>();
	     set.add(99);
	     set.add(77);
	     set.add(1);
	     set.add(1);
	     System.out.println(set);
	     System.out.println("\n");
	     System.out.println("Linkedhashlist");
	     
	     //linkedhashset
	     
	     LinkedHashSet<Integer> linset = new LinkedHashSet<>();
	     linset.add(1);
	     linset.add(11);
	     linset.add(99);
	     linset.add(3);
	     
	     Iterator<Integer> itrr = linset.iterator();
	     while(itrr.hasNext())
	     {
	    	 System.out.println(itrr.next());
	     }
	     
	     
	     
	}      
}
