package com.collections;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class mapexample {
	public static void main(String args[])
	{
		//HASHMAP
		System.out.println("HASHMAP");
		HashMap<Integer,String> map = new HashMap<>();
		map.put(1, "sarvesh");
		map.put(2, "prashanth");
		map.put(3, "Kamali");
		map.put(4,"sundar");
		
		for(Map.Entry m:map.entrySet())
		{
			System.out.println(m.getValue()+ " " +m.getKey());
		}
		System.out.println("\n");
		
		//Treemap
		System.out.println("TREEMAP");
		TreeMap<Integer, String> ex = new TreeMap<>();
		ex.put(99,"sarath");
		ex.put(1,"prashanth");
		ex.put(100,"yogi");
		
		for(Map.Entry p:ex.entrySet())
		{
			System.out.println(p.getKey()+" "+p.getValue());
		}
		
		System.out.println("\n");
		//HASHTABLE
		System.out.println("HASHTABLE");
		Hashtable<String,Integer> ls = new Hashtable<>();
		ls.put("mukesh", 11);
		ls.put("sagi", 22);
		ls.put("deepak", 33);
		
		for(Map.Entry l:ls.entrySet())
		{
			System.out.println(l.getValue()+" "+l.getKey());
		}
		
	}

}
