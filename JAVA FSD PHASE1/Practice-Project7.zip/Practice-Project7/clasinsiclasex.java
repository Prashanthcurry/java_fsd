package com.innerclass;

public class clasinsiclasex {
    private String msg="welcome to java";
    class inner
    {
    	void hello()
    	{
    		System.out.println(msg);
    	}
    }
    
    public static void main(String args[])
    {
    	clasinsiclasex obj = new clasinsiclasex();
    	clasinsiclasex.inner in = obj.new inner();
    	in.hello();
    }
}
