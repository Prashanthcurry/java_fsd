package com.innerclass;

public class innerclassexample {
         public void display()
         {
        	 class inner{
        		 int a=20;
        		 public void print()
        		 {
        			 System.out.println("Method of inner class");
        			 System.out.println("value of a is "+a);
        		 }
        		 
        		 
        	 }
        	 inner in = new inner();
    		 in.print();
         }
         
         public static void main(String args[])
         {
        	 innerclassexample ex = new innerclassexample();
        	 ex.display();
         }
}
