package com.innerclass;

public class localinnerclass {
    void display(int age)
    {
    	if(age>18)
    	{
    		class inner {
    			void validate()
    			{
    				System.out.println("validated");
    			}
    		}
    		
    		inner in = new inner();
    		in.validate();
    	}
    	else
    	{
    		System.out.println("not validated");
    	}
    }


public static void main(String args[])
{
	localinnerclass s = new localinnerclass();
	s.display(19);
	
}
}
    

