package strarrayexample;

public class stringex {
	public static void main(String args[])
	{
       System.out.println("Methods of strings");
       String str = "hello";
       System.out.println(str.length());
       
       //SUBSTRING
       String sub = "welcome";
       System.out.println(sub.substring(2));
       
       //COMPARISION
       
       String s1="hello";
       String s2="hello";
       System.out.println(s1.compareTo(s2));
       
       //ISEMPTY
       
       String s4="";
       System.out.println(s4.isEmpty());
       
       //TOLOWER
       
       String s5="WELCOME";
       System.out.println(s5.toLowerCase());
    		
       String x="Welcome to Java";
	   String y="WeLcOmE tO JaVa";
	   System.out.println(x.equals(y));

	   System.out.println("\n");
	   System.out.println("Creating StringBuffer");
	   //Creating StringBuffer and append method
	   StringBuffer ex= new StringBuffer("Welcome to Java");
	   ex.append(" enjoy ur learning ");
	   System.out.println(ex);
	   
	 //insert method
	 		ex.insert(0, 'w');
	 		System.out.println(ex);
	 		
	 //replace method
			StringBuffer sb=new StringBuffer("Hello");
			sb.replace(0, 2, "hEl");
			System.out.println(sb);
			
			//delete method
			sb.delete(0, 1);
			System.out.println(sb);
			
			//StringBuilder
			System.out.println("\n");
			System.out.println("Creating StringBuilder");
			StringBuilder sb1=new StringBuilder("Happy");
			sb1.append("Learning");
			System.out.println(sb1);

			System.out.println(sb1.delete(0, 1));

			System.out.println(sb1.insert(1, "Welcome"));

			System.out.println(sb1.reverse());
			
			System.out.println("\n");
			//STRING TO STRING BUFFER
			String str1="welcome";
			System.out.println("converting strings to string buffer");
			
			StringBuffer one = new StringBuffer(str1);
			System.out.println(one);
			
			System.out.println("\n");
			//STRING TO STRINGBUILDER
			String str2="hello";
			System.out.println("converting string to string builder");
			
			StringBuilder two = new StringBuilder(str2);
			System.out.println(two);
			
			


       
}
}
