package com.emailid;

import java.util.Scanner;

public class emailidproject {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		String[] emailId = new String[5];
		for(int i=0;i<emailId.length;i++)
		{
			System.out.println(" ENTER THE EMAIL ID OF EMPLOYEE ");
			emailId[i]=sc.next();
		}
		System.out.println("\n");
		
		System.out.println(" ARRAY OF EMAILID ");
		for(String str :emailId)
			System.out.println(str);
		
		System.out.println("\n");
		
		System.out.println(" ENTER THE EMAIL ID THAT YOU WANT TO SEARCH ");
		String search = sc.next();
		for(int i=0;i<emailId.length;i++)
		{
			if(emailId[i].equals(search))
			{
				System.out.println(" EMAILID IS FOUND AT THE INDEX " +i);
			    
			}
			
		}
	
		
		
}
	
     
}

