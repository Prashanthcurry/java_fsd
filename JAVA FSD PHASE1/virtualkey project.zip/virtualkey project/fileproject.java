package mainproject1;

import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;


public class fileproject {
	public static void main(String[] args) {
		
		System.out.println("*****\n");
        System.out.println("\t    Welcome to The Desk of \n");
        System.out.println("\t           LockedMe.com   \n");
        System.out.println("\t    Developed by Prashanth S   \n");
        System.out.println("*****\n");
	    optionsSelection();   
	 
	        }
	
	private static void CreateFileUsingFileClass() throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Enter how many file you want to create ? ");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=0;i<n;i++) {
		System.out.println("Enter the filename :");
		Scanner sc1=new Scanner(System.in);
		String filename=sc1.next();
		File file = new File("D:\\prashanth\\"+filename+".txt");
	    System.out.println("Write anything in this current file : ");
			Scanner sc2=new Scanner(System.in);
			String content=sc2.nextLine();
		    FileWriter writer=new FileWriter(file);
			writer.write(content);
			writer.flush();
			writer.close();
			}
			System.out.println("Files created !");
			}
	
	public static void deletefile() throws IOException
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter The FileName You Want To Delete");
		String delete = scan.next();
		Path path = Paths.get("D:\\prashanth\\"+delete);
		if(Files.deleteIfExists(path))
			System.out.println(delete+ " file deleted");
		else
			System.out.println(delete+ " file is not found");
	}
	
	 public static void readFileReaderClass() throws IOException
     {
		 Scanner scan = new Scanner(System.in);
		 System.out.println("Enter the FileName You Want To Search & Show The Content");
		 String search = scan.next();
    	 FileReader reader = new FileReader("D:\\prashanth\\"+search);
    	 int data;
    	 while((data=reader.read())!=-1)
    	 {
  
    		 System.out.print((char)data);
    	 }
     }
	 
	 public static void sortfilename()
     {
         Scanner scanner = new Scanner( System.in );
         System.out.println("Enter the file path: ");
         String dirPath = scanner.nextLine(); // Takes the directory path as the user input

         File folder = new File(dirPath);
         if(folder.isDirectory())
         {
             File[] fileList = folder.listFiles();

             Arrays.sort(fileList);

             System.out.println("\nTotal number of items present in the directory: " + fileList.length );

             FileFilter fileFilter = new FileFilter()
             {
                 @Override
                 public boolean accept(File file) {
                     return !file.isDirectory();
                 }
             };

             fileList = folder.listFiles(fileFilter);

             // Sort files by name
             Arrays.sort(fileList, new Comparator<Object>()
             {
                 public int compare(Object f1, Object f2) {
                     return ((File) f1).getName().compareTo(((File) f2).getName());
                 }
             });
            

             //Prints the files in file name ascending order
             for(File file:fileList)
             {
                 System.out.println(file.getName());
             }

         } 
     }
	 public static void optionsSelection() {
	        String[] arr = {"1. Retrieve current filename in ascending order",
	                "2. Business level operation menu",
	                "3. Exit from the Application",
	                
	    };
	        
	     int[] arr1 = {1,2,3};
	        int  slen = arr1.length;
	        for(int i=0; i<slen;i++){
	            System.out.println(arr[i]);}
	      	System.out.println("\nEnter your choice:\t");
		   	Scanner sc = new Scanner(System.in);
		   	int  options =  sc.nextInt();
		   	switch(options)
		   		{
		   			case 1:
		   				sortfilename();
		   				System.out.println("\n");
		   				optionsSelection();
		   				break; 	
		   			case 2:
		   				choiceSelection(); // display the all the Strings mentioned in the String array
		   				break;
		   			case 3:
		   				System.out.println("Application is closed... \nThank you!");
		   				break;
		   			default:
		   				System.out.println("Entered option is Incorrect");
		   			
		   			System.out.println("\n");
		   			optionsSelection();
		   			break;
		  
		   		}
	 }

	 public  static void choiceSelection()
	  {
		  String[] array = {"1. Add a File and its Content to the directory",
	                "2. Delete a file from Directory",
	                "3. Searching a file and showing its content",
	                "4.Exit from BLO menu"
	                };
      	 int[] arr2 = {1,2,3,4};
	        int  slength = arr2.length;
	        for(int i=0; i<slength;i++){
	            System.out.println(array[i]);
	        }	
	        System.out.println("\nSelect your option :\t");
		    Scanner s = new Scanner(System.in);
		    int option = s.nextInt();
		    switch(option) {
			   case 1:
				   try {
					CreateFileUsingFileClass();
				   }
				   catch (IOException e) {
					e.printStackTrace();
				   }
				   choiceSelection();
				   break;
				   
			   case 2:
				   try {
					deletefile();
				   } 
				   catch (Exception e) {
					e.printStackTrace();
				   }
				   choiceSelection();
				   break;
				   
			   case 3:
				   try {
					readFileReaderClass();
				   } 
				   catch (Exception e) {
					e.printStackTrace();
				   }
				   System.out.println("\n");
				   choiceSelection();
				   break;
				   
			   case 4:
				   System.out.println("Exited from the BLO menu");
				   System.out.println("\n");
				   optionsSelection();
				   break;
			   
			   default:
				   System.out.println("Entered option is incorrect");
			   
			   System.out.print("\n");
			   choiceSelection();
			   break;
	  }
	       
    }
}


